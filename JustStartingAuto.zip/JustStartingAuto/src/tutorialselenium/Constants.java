package tutorialselenium;

public class Constants {
      public static final String URL = "http://letskodeit.com";
      public static final String File_Path = "D:\\Users\\goutham.p\\eclipse-workspace\\JustStartingAuto\\bin\\tutorialselenium\\";
      public static final String File_Name = "ExcelData.xlsx";
}