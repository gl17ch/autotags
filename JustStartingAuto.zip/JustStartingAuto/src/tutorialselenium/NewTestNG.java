package tutorialselenium;

import org.testng.annotations.Test;
import tutorialselenium.ExcelRead;
public class NewTestNG {

	@Test
	public void firstTest() {
		ExcelRead obj = new ExcelRead();
		
	}
}